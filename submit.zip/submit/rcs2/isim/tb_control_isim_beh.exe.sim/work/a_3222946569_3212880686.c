/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/nfs/TUEIEDA/LabHDL/2017s/ga87dew/submit/rcs2/control.vhd";
extern char *IEEE_P_3620187407;

char *ieee_p_3620187407_sub_1496620905533649268_3965413181(char *, char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_16272557775307340295_3965413181(char *, char *, char *, char *, unsigned char );
char *ieee_p_3620187407_sub_16272557775307412169_3965413181(char *, char *, char *, char *, unsigned char );


static void work_a_3222946569_3212880686_p_0(char *t0)
{
    char t43[16];
    char t44[16];
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    char *t20;
    char *t21;
    int t22;
    char *t23;
    int t25;
    char *t26;
    char *t27;
    int t28;
    char *t29;
    char *t30;
    int t31;
    char *t32;
    char *t33;
    int t34;
    char *t35;
    char *t36;
    unsigned char t37;
    unsigned char t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;

LAB0:    xsi_set_current_line(57, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = (t4 == (unsigned char)3);
    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 4584);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(58, ng0);
    t7 = (t0 + 1352U);
    t8 = *((char **)t7);
    t9 = *((unsigned char *)t8);
    t10 = (t9 == (unsigned char)2);
    if (t10 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t1 = *((unsigned char *)t3);
    t4 = (t1 == (unsigned char)3);
    if (t4 != 0)
        goto LAB49;

LAB50:    xsi_set_current_line(107, ng0);

LAB9:    xsi_set_current_line(109, ng0);
    t2 = (t0 + 2632U);
    t3 = *((char **)t2);
    t1 = *((unsigned char *)t3);
    t2 = (t0 + 5112);
    t7 = (t2 + 56U);
    t8 = *((char **)t7);
    t11 = (t8 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t1;
    xsi_driver_first_trans_fast_port(t2);
    xsi_set_current_line(110, ng0);
    t2 = (t0 + 2792U);
    t3 = *((char **)t2);
    t1 = *((unsigned char *)t3);
    t2 = (t0 + 5176);
    t7 = (t2 + 56U);
    t8 = *((char **)t7);
    t11 = (t8 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t1;
    xsi_driver_first_trans_fast_port(t2);
    xsi_set_current_line(111, ng0);
    t2 = (t0 + 2952U);
    t3 = *((char **)t2);
    t1 = *((unsigned char *)t3);
    t2 = (t0 + 5240);
    t7 = (t2 + 56U);
    t8 = *((char **)t7);
    t11 = (t8 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t1;
    xsi_driver_first_trans_fast_port(t2);
    xsi_set_current_line(112, ng0);
    t2 = (t0 + 3112U);
    t3 = *((char **)t2);
    t1 = *((unsigned char *)t3);
    t2 = (t0 + 5304);
    t7 = (t2 + 56U);
    t8 = *((char **)t7);
    t11 = (t8 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t1;
    xsi_driver_first_trans_fast_port(t2);
    goto LAB3;

LAB5:    t2 = (t0 + 992U);
    t6 = xsi_signal_has_event(t2);
    t1 = t6;
    goto LAB7;

LAB8:    xsi_set_current_line(59, ng0);
    t7 = (t0 + 2472U);
    t11 = *((char **)t7);
    t7 = (t0 + 7866);
    t13 = xsi_mem_cmp(t7, t11, 3U);
    if (t13 == 1)
        goto LAB12;

LAB21:    t14 = (t0 + 7869);
    t16 = xsi_mem_cmp(t14, t11, 3U);
    if (t16 == 1)
        goto LAB13;

LAB22:    t17 = (t0 + 7872);
    t19 = xsi_mem_cmp(t17, t11, 3U);
    if (t19 == 1)
        goto LAB14;

LAB23:    t20 = (t0 + 7875);
    t22 = xsi_mem_cmp(t20, t11, 3U);
    if (t22 == 1)
        goto LAB15;

LAB24:    t23 = (t0 + 7878);
    t25 = xsi_mem_cmp(t23, t11, 3U);
    if (t25 == 1)
        goto LAB16;

LAB25:    t26 = (t0 + 7881);
    t28 = xsi_mem_cmp(t26, t11, 3U);
    if (t28 == 1)
        goto LAB17;

LAB26:    t29 = (t0 + 7884);
    t31 = xsi_mem_cmp(t29, t11, 3U);
    if (t31 == 1)
        goto LAB18;

LAB27:    t32 = (t0 + 7887);
    t34 = xsi_mem_cmp(t32, t11, 3U);
    if (t34 == 1)
        goto LAB19;

LAB28:
LAB20:    xsi_set_current_line(76, ng0);

LAB11:    goto LAB9;

LAB12:    xsi_set_current_line(61, ng0);
    t35 = (t0 + 1192U);
    t36 = *((char **)t35);
    t37 = *((unsigned char *)t36);
    t38 = (t37 == (unsigned char)3);
    if (t38 != 0)
        goto LAB30;

LAB32:    xsi_set_current_line(67, ng0);

LAB31:    goto LAB11;

LAB13:    xsi_set_current_line(69, ng0);
    t2 = (t0 + 4664);
    t3 = (t2 + 56U);
    t7 = *((char **)t3);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(69, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t2 = (t0 + 7832U);
    t7 = (t0 + 7893);
    t11 = (t44 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 0;
    t12 = (t11 + 4U);
    *((int *)t12) = 2;
    t12 = (t11 + 8U);
    *((int *)t12) = 1;
    t13 = (2 - 0);
    t45 = (t13 * 1);
    t45 = (t45 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t45;
    t12 = ieee_p_3620187407_sub_1496620905533649268_3965413181(IEEE_P_3620187407, t43, t3, t2, t7, t44);
    t14 = (t43 + 12U);
    t45 = *((unsigned int *)t14);
    t46 = (1U * t45);
    t1 = (3U != t46);
    if (t1 == 1)
        goto LAB35;

LAB36:    t15 = (t0 + 4728);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 3U);
    xsi_driver_first_trans_fast(t15);
    xsi_set_current_line(69, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t0 + 4792);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 2U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(69, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t0 + 4856);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 2U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB11;

LAB14:    xsi_set_current_line(70, ng0);
    t2 = (t0 + 4920);
    t3 = (t2 + 56U);
    t7 = *((char **)t3);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(70, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t2 = (t0 + 7832U);
    t7 = (t0 + 7896);
    t11 = (t44 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 0;
    t12 = (t11 + 4U);
    *((int *)t12) = 2;
    t12 = (t11 + 8U);
    *((int *)t12) = 1;
    t13 = (2 - 0);
    t45 = (t13 * 1);
    t45 = (t45 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t45;
    t12 = ieee_p_3620187407_sub_1496620905533649268_3965413181(IEEE_P_3620187407, t43, t3, t2, t7, t44);
    t14 = (t43 + 12U);
    t45 = *((unsigned int *)t14);
    t46 = (1U * t45);
    t1 = (3U != t46);
    if (t1 == 1)
        goto LAB37;

LAB38:    t15 = (t0 + 4728);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 3U);
    xsi_driver_first_trans_fast(t15);
    goto LAB11;

LAB15:    xsi_set_current_line(71, ng0);
    t2 = (t0 + 4920);
    t3 = (t2 + 56U);
    t7 = *((char **)t3);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(71, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t2 = (t0 + 7832U);
    t7 = (t0 + 7899);
    t11 = (t44 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 0;
    t12 = (t11 + 4U);
    *((int *)t12) = 2;
    t12 = (t11 + 8U);
    *((int *)t12) = 1;
    t13 = (2 - 0);
    t45 = (t13 * 1);
    t45 = (t45 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t45;
    t12 = ieee_p_3620187407_sub_1496620905533649268_3965413181(IEEE_P_3620187407, t43, t3, t2, t7, t44);
    t14 = (t43 + 12U);
    t45 = *((unsigned int *)t14);
    t46 = (1U * t45);
    t1 = (3U != t46);
    if (t1 == 1)
        goto LAB39;

LAB40:    t15 = (t0 + 4728);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 3U);
    xsi_driver_first_trans_fast(t15);
    xsi_set_current_line(71, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t0 + 4792);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 2U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(71, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t0 + 4856);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 2U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB11;

LAB16:    xsi_set_current_line(72, ng0);
    t2 = (t0 + 4984);
    t3 = (t2 + 56U);
    t7 = *((char **)t3);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(72, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t2 = (t0 + 7832U);
    t7 = (t0 + 7902);
    t11 = (t44 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 0;
    t12 = (t11 + 4U);
    *((int *)t12) = 2;
    t12 = (t11 + 8U);
    *((int *)t12) = 1;
    t13 = (2 - 0);
    t45 = (t13 * 1);
    t45 = (t45 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t45;
    t12 = ieee_p_3620187407_sub_1496620905533649268_3965413181(IEEE_P_3620187407, t43, t3, t2, t7, t44);
    t14 = (t43 + 12U);
    t45 = *((unsigned int *)t14);
    t46 = (1U * t45);
    t1 = (3U != t46);
    if (t1 == 1)
        goto LAB41;

LAB42:    t15 = (t0 + 4728);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 3U);
    xsi_driver_first_trans_fast(t15);
    goto LAB11;

LAB17:    xsi_set_current_line(73, ng0);
    t2 = (t0 + 4984);
    t3 = (t2 + 56U);
    t7 = *((char **)t3);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(73, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t2 = (t0 + 7832U);
    t7 = (t0 + 7905);
    t11 = (t44 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 0;
    t12 = (t11 + 4U);
    *((int *)t12) = 2;
    t12 = (t11 + 8U);
    *((int *)t12) = 1;
    t13 = (2 - 0);
    t45 = (t13 * 1);
    t45 = (t45 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t45;
    t12 = ieee_p_3620187407_sub_1496620905533649268_3965413181(IEEE_P_3620187407, t43, t3, t2, t7, t44);
    t14 = (t43 + 12U);
    t45 = *((unsigned int *)t14);
    t46 = (1U * t45);
    t1 = (3U != t46);
    if (t1 == 1)
        goto LAB43;

LAB44:    t15 = (t0 + 4728);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 3U);
    xsi_driver_first_trans_fast(t15);
    xsi_set_current_line(73, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t0 + 4792);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 2U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(73, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t0 + 4856);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 2U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB11;

LAB18:    xsi_set_current_line(74, ng0);
    t2 = (t0 + 5048);
    t3 = (t2 + 56U);
    t7 = *((char **)t3);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(74, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t2 = (t0 + 7832U);
    t7 = (t0 + 7908);
    t11 = (t44 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 0;
    t12 = (t11 + 4U);
    *((int *)t12) = 2;
    t12 = (t11 + 8U);
    *((int *)t12) = 1;
    t13 = (2 - 0);
    t45 = (t13 * 1);
    t45 = (t45 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t45;
    t12 = ieee_p_3620187407_sub_1496620905533649268_3965413181(IEEE_P_3620187407, t43, t3, t2, t7, t44);
    t14 = (t43 + 12U);
    t45 = *((unsigned int *)t14);
    t46 = (1U * t45);
    t1 = (3U != t46);
    if (t1 == 1)
        goto LAB45;

LAB46:    t15 = (t0 + 4728);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 3U);
    xsi_driver_first_trans_fast(t15);
    goto LAB11;

LAB19:    xsi_set_current_line(75, ng0);
    t2 = (t0 + 5048);
    t3 = (t2 + 56U);
    t7 = *((char **)t3);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(75, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t2 = (t0 + 7832U);
    t7 = (t0 + 7911);
    t11 = (t44 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 0;
    t12 = (t11 + 4U);
    *((int *)t12) = 2;
    t12 = (t11 + 8U);
    *((int *)t12) = 1;
    t13 = (2 - 0);
    t45 = (t13 * 1);
    t45 = (t45 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t45;
    t12 = ieee_p_3620187407_sub_1496620905533649268_3965413181(IEEE_P_3620187407, t43, t3, t2, t7, t44);
    t14 = (t43 + 12U);
    t45 = *((unsigned int *)t14);
    t46 = (1U * t45);
    t1 = (3U != t46);
    if (t1 == 1)
        goto LAB47;

LAB48:    t15 = (t0 + 4728);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 3U);
    xsi_driver_first_trans_fast(t15);
    xsi_set_current_line(75, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t0 + 4792);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 2U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(75, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t0 + 4856);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 2U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB11;

LAB29:;
LAB30:    xsi_set_current_line(62, ng0);
    t35 = (t0 + 4664);
    t39 = (t35 + 56U);
    t40 = *((char **)t39);
    t41 = (t40 + 56U);
    t42 = *((char **)t41);
    *((unsigned char *)t42) = (unsigned char)3;
    xsi_driver_first_trans_fast(t35);
    xsi_set_current_line(63, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t2 = (t0 + 7832U);
    t7 = (t0 + 7890);
    t11 = (t44 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 0;
    t12 = (t11 + 4U);
    *((int *)t12) = 2;
    t12 = (t11 + 8U);
    *((int *)t12) = 1;
    t13 = (2 - 0);
    t45 = (t13 * 1);
    t45 = (t45 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t45;
    t12 = ieee_p_3620187407_sub_1496620905533649268_3965413181(IEEE_P_3620187407, t43, t3, t2, t7, t44);
    t14 = (t43 + 12U);
    t45 = *((unsigned int *)t14);
    t46 = (1U * t45);
    t1 = (3U != t46);
    if (t1 == 1)
        goto LAB33;

LAB34:    t15 = (t0 + 4728);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 3U);
    xsi_driver_first_trans_fast(t15);
    xsi_set_current_line(64, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t0 + 4792);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 2U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(65, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t0 + 4856);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 2U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB31;

LAB33:    xsi_size_not_matching(3U, t46, 0);
    goto LAB34;

LAB35:    xsi_size_not_matching(3U, t46, 0);
    goto LAB36;

LAB37:    xsi_size_not_matching(3U, t46, 0);
    goto LAB38;

LAB39:    xsi_size_not_matching(3U, t46, 0);
    goto LAB40;

LAB41:    xsi_size_not_matching(3U, t46, 0);
    goto LAB42;

LAB43:    xsi_size_not_matching(3U, t46, 0);
    goto LAB44;

LAB45:    xsi_size_not_matching(3U, t46, 0);
    goto LAB46;

LAB47:    xsi_size_not_matching(3U, t46, 0);
    goto LAB48;

LAB49:    xsi_set_current_line(81, ng0);
    t2 = (t0 + 2472U);
    t7 = *((char **)t2);
    t2 = (t0 + 7914);
    t13 = xsi_mem_cmp(t2, t7, 3U);
    if (t13 == 1)
        goto LAB52;

LAB59:    t11 = (t0 + 7917);
    t16 = xsi_mem_cmp(t11, t7, 3U);
    if (t16 == 1)
        goto LAB53;

LAB60:    t14 = (t0 + 7920);
    t19 = xsi_mem_cmp(t14, t7, 3U);
    if (t19 == 1)
        goto LAB54;

LAB61:    t17 = (t0 + 7923);
    t22 = xsi_mem_cmp(t17, t7, 3U);
    if (t22 == 1)
        goto LAB55;

LAB62:    t20 = (t0 + 7926);
    t25 = xsi_mem_cmp(t20, t7, 3U);
    if (t25 == 1)
        goto LAB56;

LAB63:    t23 = (t0 + 7929);
    t28 = xsi_mem_cmp(t23, t7, 3U);
    if (t28 == 1)
        goto LAB57;

LAB64:
LAB58:    xsi_set_current_line(96, ng0);

LAB51:    goto LAB9;

LAB52:    xsi_set_current_line(83, ng0);
    t26 = (t0 + 1192U);
    t27 = *((char **)t26);
    t5 = *((unsigned char *)t27);
    t6 = (t5 == (unsigned char)3);
    if (t6 != 0)
        goto LAB66;

LAB68:    xsi_set_current_line(89, ng0);

LAB67:    goto LAB51;

LAB53:    xsi_set_current_line(91, ng0);
    t2 = (t0 + 4664);
    t3 = (t2 + 56U);
    t7 = *((char **)t3);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(91, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t2 = (t0 + 7832U);
    t7 = (t0 + 7935);
    t11 = (t44 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 0;
    t12 = (t11 + 4U);
    *((int *)t12) = 2;
    t12 = (t11 + 8U);
    *((int *)t12) = 1;
    t13 = (2 - 0);
    t45 = (t13 * 1);
    t45 = (t45 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t45;
    t12 = ieee_p_3620187407_sub_1496620905533649268_3965413181(IEEE_P_3620187407, t43, t3, t2, t7, t44);
    t14 = (t43 + 12U);
    t45 = *((unsigned int *)t14);
    t46 = (1U * t45);
    t1 = (3U != t46);
    if (t1 == 1)
        goto LAB71;

LAB72:    t15 = (t0 + 4728);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 3U);
    xsi_driver_first_trans_fast(t15);
    xsi_set_current_line(91, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t0 + 4792);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 2U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(91, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t44 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 2;
    t8 = (t7 + 4U);
    *((int *)t8) = 1;
    t8 = (t7 + 8U);
    *((int *)t8) = -1;
    t13 = (1 - 2);
    t48 = (t13 * -1);
    t48 = (t48 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t48;
    t8 = ieee_p_3620187407_sub_16272557775307340295_3965413181(IEEE_P_3620187407, t43, t2, t44, (unsigned char)3);
    t11 = (t43 + 12U);
    t48 = *((unsigned int *)t11);
    t49 = (1U * t48);
    t1 = (2U != t49);
    if (t1 == 1)
        goto LAB73;

LAB74:    t12 = (t0 + 4856);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t8, 2U);
    xsi_driver_first_trans_fast_port(t12);
    goto LAB51;

LAB54:    xsi_set_current_line(92, ng0);
    t2 = (t0 + 4920);
    t3 = (t2 + 56U);
    t7 = *((char **)t3);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(92, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t2 = (t0 + 7832U);
    t7 = (t0 + 7938);
    t11 = (t44 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 0;
    t12 = (t11 + 4U);
    *((int *)t12) = 2;
    t12 = (t11 + 8U);
    *((int *)t12) = 1;
    t13 = (2 - 0);
    t45 = (t13 * 1);
    t45 = (t45 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t45;
    t12 = ieee_p_3620187407_sub_1496620905533649268_3965413181(IEEE_P_3620187407, t43, t3, t2, t7, t44);
    t14 = (t43 + 12U);
    t45 = *((unsigned int *)t14);
    t46 = (1U * t45);
    t1 = (3U != t46);
    if (t1 == 1)
        goto LAB75;

LAB76:    t15 = (t0 + 4728);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 3U);
    xsi_driver_first_trans_fast(t15);
    goto LAB51;

LAB55:    xsi_set_current_line(93, ng0);
    t2 = (t0 + 4920);
    t3 = (t2 + 56U);
    t7 = *((char **)t3);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(93, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t2 = (t0 + 7832U);
    t7 = (t0 + 7941);
    t11 = (t44 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 0;
    t12 = (t11 + 4U);
    *((int *)t12) = 2;
    t12 = (t11 + 8U);
    *((int *)t12) = 1;
    t13 = (2 - 0);
    t45 = (t13 * 1);
    t45 = (t45 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t45;
    t12 = ieee_p_3620187407_sub_1496620905533649268_3965413181(IEEE_P_3620187407, t43, t3, t2, t7, t44);
    t14 = (t43 + 12U);
    t45 = *((unsigned int *)t14);
    t46 = (1U * t45);
    t1 = (3U != t46);
    if (t1 == 1)
        goto LAB77;

LAB78:    t15 = (t0 + 4728);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 3U);
    xsi_driver_first_trans_fast(t15);
    xsi_set_current_line(93, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t0 + 4792);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 2U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(93, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t44 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 2;
    t8 = (t7 + 4U);
    *((int *)t8) = 1;
    t8 = (t7 + 8U);
    *((int *)t8) = -1;
    t13 = (1 - 2);
    t48 = (t13 * -1);
    t48 = (t48 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t48;
    t8 = ieee_p_3620187407_sub_16272557775307412169_3965413181(IEEE_P_3620187407, t43, t2, t44, (unsigned char)3);
    t11 = (t43 + 12U);
    t48 = *((unsigned int *)t11);
    t49 = (1U * t48);
    t1 = (2U != t49);
    if (t1 == 1)
        goto LAB79;

LAB80:    t12 = (t0 + 4856);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t8, 2U);
    xsi_driver_first_trans_fast_port(t12);
    goto LAB51;

LAB56:    xsi_set_current_line(94, ng0);
    t2 = (t0 + 5048);
    t3 = (t2 + 56U);
    t7 = *((char **)t3);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(94, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t2 = (t0 + 7832U);
    t7 = (t0 + 7944);
    t11 = (t44 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 0;
    t12 = (t11 + 4U);
    *((int *)t12) = 2;
    t12 = (t11 + 8U);
    *((int *)t12) = 1;
    t13 = (2 - 0);
    t45 = (t13 * 1);
    t45 = (t45 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t45;
    t12 = ieee_p_3620187407_sub_1496620905533649268_3965413181(IEEE_P_3620187407, t43, t3, t2, t7, t44);
    t14 = (t43 + 12U);
    t45 = *((unsigned int *)t14);
    t46 = (1U * t45);
    t1 = (3U != t46);
    if (t1 == 1)
        goto LAB81;

LAB82:    t15 = (t0 + 4728);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 3U);
    xsi_driver_first_trans_fast(t15);
    goto LAB51;

LAB57:    xsi_set_current_line(95, ng0);
    t2 = (t0 + 5048);
    t3 = (t2 + 56U);
    t7 = *((char **)t3);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(95, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t2 = (t0 + 7832U);
    t7 = (t0 + 7947);
    t11 = (t44 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 0;
    t12 = (t11 + 4U);
    *((int *)t12) = 2;
    t12 = (t11 + 8U);
    *((int *)t12) = 1;
    t13 = (2 - 0);
    t45 = (t13 * 1);
    t45 = (t45 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t45;
    t12 = ieee_p_3620187407_sub_1496620905533649268_3965413181(IEEE_P_3620187407, t43, t3, t2, t7, t44);
    t14 = (t43 + 12U);
    t45 = *((unsigned int *)t14);
    t46 = (1U * t45);
    t1 = (3U != t46);
    if (t1 == 1)
        goto LAB83;

LAB84:    t15 = (t0 + 4728);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 3U);
    xsi_driver_first_trans_fast(t15);
    xsi_set_current_line(95, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t0 + 4792);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 2U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(95, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t44 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 2;
    t8 = (t7 + 4U);
    *((int *)t8) = 1;
    t8 = (t7 + 8U);
    *((int *)t8) = -1;
    t13 = (1 - 2);
    t48 = (t13 * -1);
    t48 = (t48 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t48;
    t8 = ieee_p_3620187407_sub_16272557775307412169_3965413181(IEEE_P_3620187407, t43, t2, t44, (unsigned char)3);
    t11 = (t43 + 12U);
    t48 = *((unsigned int *)t11);
    t49 = (1U * t48);
    t1 = (2U != t49);
    if (t1 == 1)
        goto LAB85;

LAB86:    t12 = (t0 + 4856);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t8, 2U);
    xsi_driver_first_trans_fast_port(t12);
    goto LAB51;

LAB65:;
LAB66:    xsi_set_current_line(84, ng0);
    t26 = (t0 + 4664);
    t29 = (t26 + 56U);
    t30 = *((char **)t29);
    t32 = (t30 + 56U);
    t33 = *((char **)t32);
    *((unsigned char *)t33) = (unsigned char)3;
    xsi_driver_first_trans_fast(t26);
    xsi_set_current_line(85, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t2 = (t0 + 7832U);
    t7 = (t0 + 7932);
    t11 = (t44 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 0;
    t12 = (t11 + 4U);
    *((int *)t12) = 2;
    t12 = (t11 + 8U);
    *((int *)t12) = 1;
    t13 = (2 - 0);
    t45 = (t13 * 1);
    t45 = (t45 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t45;
    t12 = ieee_p_3620187407_sub_1496620905533649268_3965413181(IEEE_P_3620187407, t43, t3, t2, t7, t44);
    t14 = (t43 + 12U);
    t45 = *((unsigned int *)t14);
    t46 = (1U * t45);
    t1 = (3U != t46);
    if (t1 == 1)
        goto LAB69;

LAB70:    t15 = (t0 + 4728);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 3U);
    xsi_driver_first_trans_fast(t15);
    xsi_set_current_line(86, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t0 + 4792);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 2U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(87, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t45 = (2 - 2);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t2 = (t3 + t47);
    t7 = (t0 + 4856);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 2U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB67;

LAB69:    xsi_size_not_matching(3U, t46, 0);
    goto LAB70;

LAB71:    xsi_size_not_matching(3U, t46, 0);
    goto LAB72;

LAB73:    xsi_size_not_matching(2U, t49, 0);
    goto LAB74;

LAB75:    xsi_size_not_matching(3U, t46, 0);
    goto LAB76;

LAB77:    xsi_size_not_matching(3U, t46, 0);
    goto LAB78;

LAB79:    xsi_size_not_matching(2U, t49, 0);
    goto LAB80;

LAB81:    xsi_size_not_matching(3U, t46, 0);
    goto LAB82;

LAB83:    xsi_size_not_matching(3U, t46, 0);
    goto LAB84;

LAB85:    xsi_size_not_matching(2U, t49, 0);
    goto LAB86;

}


extern void work_a_3222946569_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3222946569_3212880686_p_0};
	xsi_register_didat("work_a_3222946569_3212880686", "isim/tb_control_isim_beh.exe.sim/work/a_3222946569_3212880686.didat");
	xsi_register_executes(pe);
}
